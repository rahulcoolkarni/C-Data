#include <iostream>
#include <initializer_list>
#include <vector>
#include <string>
#include <algorithm>
#include <numeric>
template<typename T>
class Test {
public:
	Test(std::initializer_list<T> l) {
		int size = l.size();
		auto it = l.begin();
		while(it != l.end()) {
			++it;
		}
	}
};

struct Item {
	bool selected = false ;
	std::string name;
	Item(const std::string& n) :name(n) {
	}
};
std::ostream & operator<<(std::ostream &out, const Item &item) {
	out << item.name;
	return out;
}
template<typename T>
void Print(const std::vector<T> &v, const std::string &msg) {
	std::cout << "####" << msg << "####" << std::endl;
	for (auto &x : v ) {
		std::cout << x << std::endl;
	}

}
template<typename T, typename Iterator>
T Sum(Iterator begin, Iterator end,T init) {
	T temp = T();

	//temp += init;
	while(begin != end) {
		temp += *begin;
		++begin;
	}
	return temp;
}
int main() {
	std::vector<std::vector<int>> t;
	std::vector<Item> names{
		Item("Umar"),
		Item("Ayaan"),
		Item("Raihaan"), 
		Item("Seerat"), 
		Item("Misha")
	};
	names[2].selected = true;
	names[4].selected = true;
	Print(names, "AllNames");
	//std::rotate(names.begin(), names.begin() + 3, names.end());
	std::stable_partition(names.begin(), names.end(), [](const Item &item)
	{
		return item.selected;
	});
	Print(names, "After partition");

	std::vector<int> v{ 1,3,5,8 };
	//std::cout << std::accumulate(v.begin(), v.end(), 1, std::multiplies<int>()) << std::endl;
	std::cout << Sum(v.begin(), v.end(), 0) << std::endl;
	std::vector<std::string> v2{ "Umar", "Ramakant", "Abhijeet" };
	std::cout << Sum(v2.begin(), v2.end(), std::string(""));
	return 0;
}