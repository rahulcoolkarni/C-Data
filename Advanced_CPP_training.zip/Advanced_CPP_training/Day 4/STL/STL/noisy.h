#include <iostream>
#include <vector>
using namespace std ;
class Noisy
{
		int m_ID ;
		static long m_create, m_param, m_assign, m_copyctor, m_dtor ;
		public:
		Noisy()
		{
				++m_create ;
				//	std::cout << "d[" << id << "]";
		}
		Noisy(int id) :m_ID(id)
		{
			++m_param;
			//	std::cout << "d[" << id << "]";
		}
		Noisy(const Noisy & obj)
		{
				m_ID = obj.m_ID ;
				++m_copyctor ;
		}
		Noisy &  operator =(const Noisy &obj)
		{
				m_ID = obj.m_ID ;
				++m_assign ;
				return *this ;
		}
		~Noisy()
		{
				++m_dtor ;
		}
		int GetID()const {
			return m_ID;
		}
		void SetID(int id) {
			m_ID = id;
		}
		Noisy & operator++() {
			++m_ID;
			return *this;
		}
		Noisy operator++(int){
			Noisy temp(*this);
			++m_ID;
			return temp;
		}
		friend bool operator < (const Noisy &lv, const Noisy &rv)
		{
				return lv.m_ID < rv.m_ID;
		}
		friend bool operator > (const Noisy &lv, const Noisy &rv)
		{
			return lv.m_ID > rv.m_ID;
		}
		friend bool operator == (const Noisy &lv, const Noisy &rv)
		{
				return lv.m_ID == rv.m_ID;
		}
		friend class Reporter ;
} ;
inline std::ostream & operator << (std::ostream &out, const Noisy &obj) {
	out << obj.GetID();
	return out;
}
long Noisy::m_assign = 0 ;
long Noisy::m_copyctor = 0 ;
long Noisy::m_create = 0;
long Noisy::m_param = 0 ;
long Noisy::m_dtor = 0 ;

class Reporter
{
		static Reporter m_reporter ;
		Reporter(){}
		public:
		~Reporter()
		{
#ifdef NOISEON
			cout << "Noisy default ctors : " << Noisy::m_create << endl;
			cout << "Noisy parameterized ctors : " << Noisy::m_param << endl;
				cout << "Noisy copy ctors : " << Noisy::m_copyctor << endl ;
				cout << "Noisy assignments : "<< Noisy::m_assign << endl; 
				cout << "Noisy dtors : "<< Noisy::m_dtor << endl ;
#endif
		}
} ;
Reporter Reporter::m_reporter ;


