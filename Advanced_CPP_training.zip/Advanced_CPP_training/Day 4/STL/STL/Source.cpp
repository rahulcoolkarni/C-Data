#include <vector>
#include <set>
#include <algorithm>
#include <string>
#include <iterator>
#include <list>
#include <deque>
#include <set>
#include <map>
//#define NOISEON
#include "noisy.h"
void Display(const std::vector<int> &ref) {
	std::vector<int>::const_iterator it = ref.begin();
}
void UsingVector() {
	//< > == != 
	std::vector<Noisy> v;
	v.push_back(100);
	v.push_back(200);
	v.reserve(12);
	auto v2 = *(v.end() - 1);
	
	v.pop_back(); 
	for (int i = 0; i < 10; ++i) {
		v.push_back(Noisy(i));
		//v[i] = Noisy(i);

	}
	auto it = v.begin();
	*(it+4) = 3;
	while(it != v.end()) {
		std::cout << *it << " ";
		++it;
	}
}
template<typename T>
void ShowVector(const std::vector<T> &v, const std::string &msg) {
	std::cout << "###"<< msg<<"###" << std::endl;
	for(auto val : v) {
		std::cout << val << " ";
	}
	std::cout << std::endl;
}
void VectorInt() {
	std::vector<int> v{ 3,1,9,4,1,8, 0, 1 };
	ShowVector(v, "Inital content");
	std::vector<int> dest;
	auto newend = std::remove_copy_if(v.begin(), v.end(),
		std::back_inserter(dest),
		[](int val)
	{
		if (val % 3 == 0)
			return true;
		return false;
	});
	//v.erase(newend, v.end());
	ShowVector(v, "After remove");

}
Noisy *p = nullptr;

void Add(const Noisy &ref) {
	new (p) Noisy(ref);
}

void MoveCommands() {
	std::vector<std::string> commands{ "Undo", "Redo", "Cut", "Copy", "Paste" };
	ShowVector(commands, "Source");
	std::string  arr[] = { "Undo", "Redo", "Paste" };
	std::vector<std::string> shortcuts(4);

	auto newend = std::copy_if(commands.begin(),
		commands.end(), 
		shortcuts.begin(),
		[&arr](const std::string &cmd)
	{
		for (int i = 0; i < 3; ++i) {
			if (arr[i] == cmd) {
				//shortcuts.push_back(cmd);
				return true;
			}
		}
		return false;
	}
	);
	//commands.erase(newend, commands.end());
	ShowVector(commands, "Source");

	ShowVector(shortcuts, "Destination");
}
void UsingList() {
	std::list<int> l{ 1,2,3,4,5 };
	auto it = l.begin();
	++it;
	l.erase(it);
	l.insert(it, 5);
	l.remove(2);
	l.sort();
}
void UsingDeque() {
	std::deque<int >d;
	d.push_back(3);
	d.push_front(1);
	d.size();
	d[0] = 3;
}
void Usingset() {
	std::set<int >s{ 1,6,23,9 };
	s.insert(9);
	s.insert(7);
	auto it = s.begin();
	while(it != s.end()) {
		std::cout << *it << " ";
		++it;
	}
	auto found = s.find(6);
	
}
int main() {
	int i = 1;
	int j = 0;
	j = ++i;
	j = i++;
	//p = new Noisy[10];
	//void *pbuffer = ::operator new(sizeof(Noisy) * 10);
	//p = reinterpret_cast<Noisy *>(pbuffer);
	//Add(Noisy(1));
	//
	//for (int i = 0; i < 1; ++i) {
	//	p->~Noisy();
	//	++p;
	//}
	//::operator delete(pbuffer);
	//UsingVector();
	//VectorInt();
	//MoveCommands();
	Usingset();
	return 0;
}