#include <iostream>
#include <windows.h>
#include <thread>
#include <future>
#include <mutex>
std::mutex g_mutex; 
void Downloader(const std::string &url, int retries, std::promise<int> &p) {
	for (int i = 0; i < 10; ++i) {
		std::cout << ".";
		Sleep(500);
	}
	p.set_exception(std::current_exception());
	p.set_value(700);
}
int NewDownloader() {
	for (int i = 0; i < 10; ++i) {
		std::cout << ".";
		Sleep(500);
	}
	return 3;
}
void OldCode() {
	auto result = std::async(NewDownloader);
	/*std::cout << result.get() << std::endl;*/
	//std::cout << "Started download" << std::endl;
	std::promise<int> p;
	std::thread t(Downloader, "www.download.com/winzip", 5,
		std::ref(p));
	auto t2 = std::move(t);
	std::future<int> f = p.get_future();
	std::cout << f.get() << std::endl;
	/*CreateThread(NULL, 0, [](void *p)->DWORD
	{
	Sleep(100);
	std::cout << "Thread executing";
	return 0;
	}, nullptr, 0, nullptr);*/
	std::cout << "Main doing some other work" << std::endl;
	//ExitThread(0);
	t.join();
}

class MyVector {
	std::vector<int> data;
public:
	MyVector(std::initializer_list<int> l):data(l) {
	}
	void push_back(int &elem) {
		data.push_back(elem);
		//std::this_thread::sleep_for(std::chrono::seconds(1));
	}
	int & operator [](int index)
	{
		return data[index];
	}
	int operator [](int index)const
	{
		return data[index];
	}
	int size()const {
		return data.size();
	}
};
void Thread1(const MyVector &v) {
	std::lock_guard<std::mutex> l(g_mutex);
	for (int i = 0; i < v.size(); ++i) {
		std::cout <<v[i] << std::endl;
		if (i == 5)
			return;
		std::this_thread::sleep_for(
			std::chrono::milliseconds(5));
	}
}
void Thread2(MyVector &v) {
	std::lock_guard<std::mutex> l(g_mutex);
	for (int i = 0; i < 10; ++i) {
		v.push_back(i);
		std::this_thread::sleep_for(
			std::chrono::milliseconds(5));
	}
}
void BasicThread(int x) {
	int y = 5;
	x++;
}
void Synch() {
	MyVector v{ 1,2,3,4,5,6, 7, 8, 9, 10 };
	std::vector<std::thread> threads;
	threads.push_back(std::thread(Thread1, std::ref(v)));
	threads.push_back(std::thread(Thread2, std::ref(v)));
	for (auto &x : threads) {
		x.join();
	}
	for (int i = 0; i < v.size(); ++i) {
		std::cout << v[i] << std::endl;
	}
}
class Singleton {
	static Singleton *pInstance;
public:
	static Singleton &Get() {
		if(pInstance == nullptr) {
			pInstance = new Singleton();
		}
		return *pInstance;
	}
};
Singleton* Singleton::pInstance;
int main() {
	std::thread t1([](){
		std::this_thread::sleep_for(std::chrono::hours(1));
		Singleton &ref = Singleton::Get();
	});
	std::thread t2([]() {
		Singleton &ref = Singleton::Get();
	});
	//t1.detach();
	
	t1.join();
	t2.join();
	return 0;
}
