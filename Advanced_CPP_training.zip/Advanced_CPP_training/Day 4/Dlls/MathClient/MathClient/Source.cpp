#include <iostream>
#include <windows.h>
//__declspec(dllimport)
//int Add(int, int);

int main() {
	//std::cout << Add(3, 5) << std::endl;
	HINSTANCE hDll = LoadLibraryA("Mathdll.dll");
	if(hDll == nullptr) {
		std::cout << "Could not load the dll" << std::endl;
		return -1;
	}
	typedef int(*AddFn)(int, int);
	AddFn pAdd = (AddFn)GetProcAddress(hDll, "Add");
	if(pAdd == nullptr) {
		std::cout << "Could not locate the function" << std::endl; 
		FreeLibrary(hDll);
		return -1;
	}
	std::cout << pAdd(3, 5) << std::endl;
	FreeLibrary(hDll);
	return 0;
}