#include <iostream>
#include "SString.h"
#include "trace_noisy.h"
#include <memory>
#include <fstream>

SString operator+(const SString &arg1, const SString &arg2) {
	char *ptemp = new char[arg1.GetLength() + arg2.GetLength() + 1];
	strcpy(ptemp, arg1.GetString());
	strcat(ptemp, arg2.GetString());
	SString temp(ptemp);
	delete[]ptemp;
	int *p = new int(3);
	return temp;
}
class Employee {
	SString name; 
	SString address;
public:
	//Employee(const SString &n, const SString &a):
	//	name(n), address(a) {
	//	std::cout << "Employee(const SString &)" << std::endl;
	//}
	//Employee(SString &&n, SString &&a) :
	//	name(std::move(n)), address(std::move(a)) {
	//	std::cout << "Employee(SString &&)" << std::endl;
	//}
	template<typename T1, typename T2>
	Employee(T1 &&n, T2 &&a):
		name(std::forward<T1>(n)), address(std::forward<T2>(a)) {
		
	}
};
void Bar(int &&x) {
	
}
void Foo(int && a) {
	Bar(std::move(a));
	//a cannot be use
	a++;
}
class Product {
	std::unique_ptr<int> a;
	std::ofstream out;
public:
	Product() {
		
	}
	Product(Product &obj) {
		a = std::move(obj.a);
		//out = obj.out;
	}
};
int main() {
	Product p;
	Product p1(p);

	//SString a("Ayaan");
	SString s("Umar");
	Employee emp(SString("Raihaan"), s);

	/*Employee e1(s, a);
	Employee e2(SString("Umar"), a);*/
	//SString s1("Hello"), s2("World"), sum; 
	//sum = s1 + s2;
	return 0;
}