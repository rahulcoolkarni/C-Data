#include <iostream>
#define _DOTRACE
#include "tracer.h"
class Line;

class Shape {
public:
	virtual void Draw() = 0;
	virtual void Erase(int x = 10) {
		TRACETHIS
	}
	void Refresh() {
	}
	Shape(Line *l);
	virtual ~Shape() {
		
	}
};

void Paint(Shape &s) {
	int *ptr1 = reinterpret_cast<int*>(&s);
	int *vptr = reinterpret_cast<int*>(*ptr1);
	void (*pfn)() = reinterpret_cast<void (*)()>(*(vptr+1));
	_asm mov ecx, dword ptr[ptr1]
	pfn();
}

class Rectangle : public Shape {
public:
	void Draw()override {
		TRACETHIS
			
	}
	void Erase(int x)override {
		TRACETHIS

	}
};
class Line final : public Shape {
	std::string s = "Hello";
public:
	Line():Shape(this) {
		
	}

	virtual void Erase(int x)override {
		TRACETHIS
			std::cout << x << std::endl;
		std::cout << s.c_str() << std::endl;
	}
	virtual void Draw();
	virtual void Foo() {
		
	}
};

Shape::Shape(Line *l) {
	//l->Erase();
	//this->Erase();
	std::cout << typeid(this).name() << std::endl;
	std::cout << typeid(*this).name() << std::endl;
}
void MyHandler() {
	std::cout << "You've invoked a pure virtual function" << std::endl;
}
int main() {
	_set_purecall_handler(MyHandler);
	Line l;
	Paint(l);
	return 0;
}

void Line::Draw() {
	TRACETHIS
}