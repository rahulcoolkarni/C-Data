#include <iostream>
struct Base {
	virtual void Foo() = 0; 
};
struct DirectX : virtual public Base{
	virtual void Draw() = 0;
};
struct OpenGL : virtual public Base {
	virtual void Render() = 0;
};

class Line : public DirectX, public OpenGL {
public:
	void Foo(){}
	virtual void Draw() {
		std::cout << "DirectX::Draw" << std::endl; 
	}
	virtual void Render() {
		std::cout << "OpenGL::Render" << std::endl;
	}
};
class Rectangle : public DirectX {
public:
	void Foo(){}
	void Draw() {
		std::cout << "Rectangle::Draw" << std::endl;
	}
};

void Paint(DirectX *ref) {
	ref->Draw();
	OpenGL *p = dynamic_cast<OpenGL*>(ref);
	if(p == nullptr) {
		std::cout << "Cannot cast because types are incompatible" << std::endl; 
	}
	else {
		p->Render();
	}
	/*if(typeid(*ref) == typeid(Line)) {
		Line *l = static_cast<Line*>(ref);
		OpenGL *p = l;
		p->Render();
	}*/
	
}
class Parent {
public : 
	Parent(int x) {
		std::cout << "Parent() : " << x<<  std::endl; 
}
	virtual void Foo(){}
};
class Left :   public Parent {
public:
	Left(int x):Parent(5) {
		std::cout << "Left()" << std::endl;
	}
};
class Right :  public Parent {
public:
	Right(int x):Parent(10) {
		std::cout << "Right()" << std::endl;
	}
};
class Child : public Left, public Right {
	int x;
	int y;
public:
	Child(int x):Left(x),  Right(x) {
		std::cout << "Child()" << std::endl;
	}
};

void Print(Base *b) {
	b->Foo();
	//DirectX *p = static_cast<DirectX*>(b);
	//OpenGL *p2 = static_cast<OpenGL*>(b);
}
int main() {
	Base *p = static_cast<DirectX*> (new Line());
	Child d(0); 
	d.Foo();
	return 0;
}