#pragma once
template<typename T>
struct DefaultDeleter {
	void operator()(T *p) {
		delete p;
	}
};
template<typename T, typename TDeleter = DefaultDeleter<T> >
class UniqueHandle {
	T *m_ptr;
	bool isOwned = false;
public:
	UniqueHandle(T *p):m_ptr(p), isOwned(true) {
		
	}
	/*
	UniqueHandle(UniqueHandle<T> &ref) {
		m_ptr = ref.m_ptr;
		ref.m_ptr = nullptr;
		isOwned = true;
		ref.isOwned = false;
	}
	UniqueHandle & operator=(const UniqueHandle<T> &ref) {
		if(this != &ref) {
			m_ptr = ref.m_ptr;
			ref.m_ptr = nullptr;
			isOwned = true;
			ref.isOwned = false;
		}
		return *this;
	}*/

	
	UniqueHandle(const UniqueHandle<T> &ref) = delete;
	UniqueHandle & operator=(const UniqueHandle<T> &r) = delete;
	

	~UniqueHandle() {
		TDeleter d;
		d(m_ptr);
		//delete m_ptr;
	}
	T * operator ->() {
		return m_ptr;
	}
	T & operator *() {
		return *m_ptr;
	}
	T * Get() {
		return m_ptr;
	}
};

template<typename T>
class UniqueHandle<T[]> {
	T *m_ptr;
public:
	UniqueHandle(T *p) :m_ptr(p){

	}

	UniqueHandle(const UniqueHandle<T> &ref) = delete;
	UniqueHandle & operator=(const UniqueHandle<T> &r) = delete;
	T & operator[](int index)
	{
		return m_ptr[index];
	}
	const T & operator[](int index)const
	{
		return m_ptr[index];
	}
	~UniqueHandle() {
		delete[] m_ptr;
	}
	T & operator *() {
		return *m_ptr;
	}
	T * Get() {
		return m_ptr;
	}
};