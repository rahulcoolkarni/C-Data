#include <iostream>
#include <exception>
#include <cstdio>
#include <windows.h>
#include "UniqueHandle.h"
struct FileDeleter {
	void operator()(FILE *fp) {
		fclose(fp);
		std::cout << "File is closed" << std::endl;
	}
};

void ReadFile() {
	try {
		UniqueHandle<char[]> p = new char[512];
		UniqueHandle<int> pInt = new int;
		//pInt[0] = 1 ;
		
		UniqueHandle<FILE, FileDeleter> fp = fopen("Source.cpp", "r");
		if (fp.Get() == nullptr) {
			throw std::exception("File does not exist");
		}
		fgets(p.Get(), 512, fp.Get());
		p[0] = 'a';
		*pInt = 3;
		std::cout << p.Get() << std::endl;
		//fclose(fp);
	}catch(std::exception &ex) {
		std::cout << ex.what() << std::endl;
		throw;
	}
}
void StartProcessing() {
	ReadFile();
}

int main() {

	try {
		std::cout << "Reading from file" << std::endl;
		StartProcessing();
	}catch(std::exception &ex) {
		std::cout << ex.what() << std::endl;
	}
	return 0;
}