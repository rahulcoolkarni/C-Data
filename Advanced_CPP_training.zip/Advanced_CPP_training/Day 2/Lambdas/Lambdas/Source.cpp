#include <iostream>
#include <memory>
#include <windows.h>
void Foo(int *x) {
	int i = *x;
	std::cout << i << std::endl;
	free(x);
}
struct Deleter {
	void operator()(int *x) {
		free(x);
	}
};
template<typename T>
void Invoke(T t) {
	t(3);
}
auto Foo(int x) {
	return x;
}
int main() {
	Invoke([](int x)
	{
		
	});
	//C+14 polymorphic lambda
	auto sp = [](auto &x, auto &y)->auto
	{
		int temp = x;
		x = y;
		y = temp;
		
	};
	int i = 0, j = 10;
	auto fn = [](int *p)
	{
		
		std::cout << __FUNCSIG__ << std::endl;
		free(p);
		std::cout << "Using lambda as custom deleter" << std::endl;
	};
	

	std::shared_ptr<int> s1((int*)malloc(j), [j](int *p)
	{

		std::cout << __FUNCSIG__ << std::endl;
		free(p);
		std::cout << "Using lambda as custom deleter" << std::endl;
	} );

	std::shared_ptr<int >s2((int*)malloc(4),fn);
	std::cout << typeid(fn).name() << std::endl;

	QueueUserWorkItem([](void *p)->DWORD
	{
		auto fn = [](int x)
		{
			
		};
		fn(3);
		std::cout << "Background thread" << std::endl;
		return 0;
	}, nullptr, WT_EXECUTEDEFAULT);

	return 0;
}