#include <crtdbg.h>
char *p = nullptr;
char * Init() {
	p = new char[4];
	return p;
}
void Uninit() {
	delete[] p; 
}