#include <iostream>
#include <memory>
struct Downloader;
struct Dialog {
	std::shared_ptr<Downloader> m_downloader;
	void UpdateProgressBar() {
		
	}
	Dialog() {
		std::cout << "Dialog" << std::endl; 
	}
	~Dialog() {
		std::cout << "~Dialog" << std::endl;
	}
};
struct Downloader {
	std::weak_ptr<Dialog> m_dialog;
	void StartDownload() {
		
	}
	Downloader() {
		std::cout << "Downloader" << std::endl;
	}
	~Downloader() {
		std::cout << "~Downloader" << std::endl;
	}
};
void Print(std::weak_ptr<int> wp) {
	if(!wp.expired()) {			//1
		std::shared_ptr<int> sh = wp.lock();	//2
		std::cout << *sh << std::endl;
	}//1
}
int main() {
	std::shared_ptr<Dialog> pDialog(new Dialog);
	std::shared_ptr<Downloader> pDownloader(new Downloader);
	std::cout << "DIALOG : " << pDialog.use_count() << std::endl;
	std::cout << "DOWNLOADER : " << pDownloader.use_count() << std::endl;
	pDialog->m_downloader = pDownloader;
	pDownloader->m_dialog = pDialog;

	std::cout << "DIALOG : " << pDialog.use_count() << std::endl;
	std::cout << "DOWNLOADER : " << pDialog.use_count() << std::endl;

	//std::weak_ptr<int>wp;
	//{
	//	auto sp(std::make_shared<int>(5));
	//	wp = sp;
	//}
	//Print(wp);
	//1


}