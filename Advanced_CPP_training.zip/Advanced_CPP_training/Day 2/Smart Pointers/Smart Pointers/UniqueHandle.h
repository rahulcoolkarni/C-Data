#pragma once
template<typename T>
class UniqueHandle {
	T *m_ptr;
	//bool isOwned = false;
public:
	UniqueHandle(T *p):m_ptr(p) {
		
	}
	UniqueHandle(UniqueHandle<T> &&ref) {
		m_ptr = ref.m_ptr;
		ref.m_ptr = nullptr;
	}
	/*
	UniqueHandle(UniqueHandle<T> &ref) {
		m_ptr = ref.m_ptr;
		ref.m_ptr = nullptr;
		isOwned = true;
		ref.isOwned = false;
	}
	UniqueHandle & operator=(const UniqueHandle<T> &ref) {
		if(this != &ref) {
			m_ptr = ref.m_ptr;
			ref.m_ptr = nullptr;
			isOwned = true;
			ref.isOwned = false;
		}
		return *this;
	}*/

	
	UniqueHandle(const UniqueHandle<T> &ref) = delete;
	UniqueHandle & operator=(const UniqueHandle<T> &r) = delete;
	

	~UniqueHandle() {
		delete m_ptr;
	}
	T * operator ->() {
		return m_ptr;
	}
	T & operator *() {
		return *m_ptr;
	}
};

template<typename T>
UniqueHandle<T> CreateUnique(T && value) {
	return UniqueHandle<T>(new T(value));
}