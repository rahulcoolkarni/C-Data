#include <iostream>
#include <windows.h>
#include <vector>
#define TRACEON
#include "trace_noisy.h"
#include "UniqueHandle.h"
#include "SharedHandle.h"
#include <memory>


void Display(UniqueHandle<Number> n) {
	std::cout << n->GetID() << std::endl; 
}
struct IntDeleter {
	void operator()(int *p) {
		free(p);
		std::cout << "Malloc deleter" <<  std::endl;
	}
};
void Print(UniqueHandle<int> u) {
	
}
int main() {
	
	//MessageBoxA(NULL, NULL, NULL, 0);
	//char *p = new char[5];
	//p[0] = 'A';
	//p[1] = 'B';
	//p[2] = '\0';
	//std::cout << p << std::endl; 
	/*UniqueHandle<Number> p = new Number;
	p->SetID(6);
	std::cout << (*p).GetID() << std::endl;

	UniqueHandle<Number>p2(p);

	Display(p2);
	std::vector<std::shared_ptr<Number>> vn;
	vn.push_back(std::shared_ptr<Number>(new Number(1)));
	vn.push_back(std::shared_ptr<Number>(new Number(2)));
	vn.push_back(std::shared_ptr<Number>(new Number(3)));
	vn.push_back(std::shared_ptr<Number>(new Number(4)));
	vn.push_back(std::shared_ptr<Number>(new Number(5)));

	std::shared_ptr<Number> i (vn[0]);
	i.reset();*/
/*
	auto p = vn[0];
	std::cout << p->GetID() << std::endl; 
	auto p2 = vn[0];
	std::cout << p2->GetID() << std::endl; 

	std::shared_ptr<Number> a1(std::make_shared<Number>(5));
	std::shared_ptr<Number> a2(a1);
	std::cout << a1->GetID() << std::endl;
	std::shared_ptr<Number> a3(new Number(10));
	std::shared_ptr<Number> a4(a3);
	a3 = a1 ;
	std::shared_ptr < Number> s1;
	a3.reset();
	a3.get();


	auto sh(CreateShared<Number>(5));
	std::cout << sh->GetID() << std::endl;*/
	std::unique_ptr<int, IntDeleter> up((int*)malloc(4));
	IntDeleter d;

	std::shared_ptr<int> up2((int*)malloc(4), d);
	UniqueHandle<int> u(CreateUnique<int>(5));
	static_cast<UniqueHandle<int>&&>(u);
	//Print(std::move(u));
	std::auto_ptr<int> a(new int(5));
	std::auto_ptr<int> a2(a);

	UniqueHandle<int> ref(std::move(u));
	return 0;
}