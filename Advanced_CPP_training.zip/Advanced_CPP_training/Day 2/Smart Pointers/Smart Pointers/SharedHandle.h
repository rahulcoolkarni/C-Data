#pragma once
template<typename T>
class SharedHandle {
	//in-class initialization
	T *m_ptr=nullptr;
	int *m_count=nullptr;
public:
	SharedHandle() {
		
	}
	void Reset(T *ptr=nullptr) {
		if(*m_count != 0)
			Decrement();
		if (ptr != nullptr) {
			m_ptr = ptr;
			m_count = new int(1);
		}else {
			m_ptr = nullptr;
			m_count = nullptr;
		}
	}
	SharedHandle(T *p) :m_ptr(p) {
		m_count = new int(1);
	}

	SharedHandle(SharedHandle<T> &ref) {
		m_ptr = ref.m_ptr;
		m_count = ref.m_count;
		++*m_count;
	
	}
	SharedHandle & operator=(const SharedHandle<T> &ref) {
		if (this != &ref) {
			Decrement();
			m_ptr = ref.m_ptr;
			m_count = ref.m_count;
			++*m_count;
		}
		return *this;
	}
	void Decrement() {
		if (--*m_count == 0) {
			delete m_ptr;
			delete m_count;
		}
	}
	~SharedHandle() {
		Decrement();
	}
	T * operator ->() {
		return m_ptr;
	}
	T & operator *() {
		return *m_ptr;
	}
};
template<typename T>
SharedHandle<T> CreateShared(T && value) {
	return SharedHandle<T>(new T(std::forward(value)));
}