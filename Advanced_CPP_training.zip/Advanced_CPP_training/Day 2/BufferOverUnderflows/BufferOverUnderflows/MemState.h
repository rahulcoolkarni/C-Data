#pragma once
#include <crtdbg.h>
#include <sstream>
#include <windows.h>
#include <iostream>

class MemState {
	_CrtMemState m_start, m_end;
	const char *m_pFunction;
	const char *m_pFile;
public:
	MemState(const char *file, const char *userdefined=nullptr):
		m_pFunction(userdefined),
	m_pFile(file){
		_CrtMemCheckpoint(&m_start);
	}
	~MemState() {
		_CrtMemCheckpoint(&m_end);
		_CrtMemState diff;
		_CrtMemDifference(&diff, &m_start, &m_end);
		std::stringstream msg;
		msg << "Dumping statistics for function [" 
			<< (m_pFunction == nullptr ? "" : m_pFunction)
			<< "] in file [" 
			<< m_pFile 
			<< "]" 
			<< std::endl;
		OutputDebugStringA(msg.str().c_str());
		_CrtMemDumpStatistics(&diff);
	}
};
#ifdef _DEBUG
#define MEMCHECK MemState _memstateobj1( __FILE__,__FUNCSIG__) ;
#define MEMCHECKMSG(msg) MemState _memstateobj2( __FILE__,msg) ;
#else
#define MEMCHECK
#endif

class HeapChecker {
	const char *m_pFunction;
	const char *m_pFile;
public:
	HeapChecker(const char *file, const char *fun) :
		m_pFunction(fun),
		m_pFile(file) {
	}
	~HeapChecker() {
		if (_CrtCheckMemory() == 0) {
			std::cout << "######MEMORY CORRUPTED DETECTED######" << std::endl;
			std::cout << "in function [" << m_pFunction << "] in file [" << m_pFile << "]" << std::endl;
		}
	}
};
#ifndef NDEBUG
#define HEAPCHECK HeapChecker _hobj(__FILE__, __FUNCSIG__) ;
#else
#define HEAPCHECK
#endif