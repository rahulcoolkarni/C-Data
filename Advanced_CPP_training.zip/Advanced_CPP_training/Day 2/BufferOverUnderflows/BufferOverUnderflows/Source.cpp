#include <iostream>
#include "MemState.h"
char * CreateString(const char *p) {
	HEAPCHECK
	char *pstr = new char[strlen(p)];
	//strcpy(pstr, p);
	pstr[-1] = 'a';
	return pstr;
}
int * AcceptConnection() {
	HEAPCHECK
		int *p = new int(7);
	p[1] = 2;
	return p;
}
char *Init();
void Uninit();
int main() {
	
	HEAPCHECK
	//_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_CHECK_ALWAYS_DF);
	char *p = CreateString("Hello world");

	std::cout << p << std::endl;
	int *pInt = AcceptConnection();

	std::cout << "End of program" << std::endl;
	delete[] p;
	delete pInt;

	//char *p = Init();
	//std::cout << "Allocated memory" << std::endl;
	//p[6] = 'a';
	//Uninit();
	return 0;
}