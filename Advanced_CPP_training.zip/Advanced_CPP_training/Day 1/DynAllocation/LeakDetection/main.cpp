#include "SString.h"
#include <crtdbg.h>
#include "MemState.h"
#define new DEBUG_NEW

class Test {
	//MEMCHECKMSG("Test")
  MemState _memstateobj2 = MemState( __FILE__,typeid(Test).name()) ;
public:
	Test() {
		int *p = new int(3);
	}
	~Test() {
		
	}
};
void AllocateLargeBlocks() {
	int i;
	MEMCHECK
	int *p2 = new int(3);
	int *p4 = (int *)malloc(4);
	free(p4);
}
void ReceivePackets() {
	int i;
	MEMCHECK
	char *p = new char[6];
	strcpy(p, "Hello");
}
int main() {
	Test t;
	//_crtBreakAlloc = 62;
	//_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	/*_CrtMemState start, end;
	_CrtMemCheckpoint(&start);
	AllocateLargeBlocks();
	_CrtMemCheckpoint(&end);

	_CrtMemState diff;
	_CrtMemDifference(&diff, &start, &end);
	_CrtMemDumpStatistics(&diff);*/

	AllocateLargeBlocks();
	ReceivePackets();
	//delete p2;
	return 0;
}