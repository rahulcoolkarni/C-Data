#ifndef SSTRING_H
#define SSTRING_H
#define _CRTDBG_MAP_ALLOC
#include <iostream>

class SString
{
	char *m_p_str;
	int m_Length;
public:
	SString();
	SString(const char *pstr);
	SString(const SString &obj);
	SString & operator=(const SString &obj);

	~SString();
	int GetLength()const;
	const char *GetString()const ;
	void SetString(const char *pstr);
	void Display() {
		std::cout << m_p_str << std::endl;
		std::cout << m_Length << std::endl;
	}
	char operator[](int index)const 
	{
		return m_p_str[index];
	}
	char &operator[](int index)
	{
		return m_p_str[index];
	}
	  
};
#define DEBUG_NEW new(_NORMAL_BLOCK, __FILE__, __LINE__)
#endif //SSTRING_H
