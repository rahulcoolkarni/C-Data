#include "leak_lib.h"
#define TRACEON
//#include "trace_noisy.h"
#define NOISEON
//#include "noisy.h"

#include <cstddef>
class Test {
public:
	void * operator new(size_t size){
		return malloc(size);
	}
		void operator delete(void *p) {
		free(p);
	}

};
//#ifndef NDEBUG
//#define new DEBUG_NEW
//#endif
int main() {
	Test *t = ::new Test();
	::delete t;
	//Noisy n[5] = { 1,2,3,4,5 };
	//for (int i = 0; i < 5; ++i) {
	//	n[0] = i;
	//}
	/*Noisy *p = new Noisy[5];
	for (int i = 0; i < 5;  ++i) {
		p[i].SetID(i);
	}
	delete[]p;*/
	std::string *p2 = new std::string("hello");
	//delete p2;
	int *p = new int(3);
	//std::cout << *p << std::endl; 
	//delete p;
	return 0;
}