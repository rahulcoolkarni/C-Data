#include "leak_lib.h"
#include <iostream>
Allocator g_Alloc;
void * operator new(size_t size,
	int lineno, 
	const char *function, 
	const char *file){
	//std::cout << "My new" << std::endl;
	void *p = malloc(sizeof(MemoryBlock) + size);
	MemoryBlock *pMemBlock = new(p)MemoryBlock(lineno, function, file);

	g_Alloc.Allocate(pMemBlock);
	void *useradd = reinterpret_cast<char*>(p) + sizeof(MemoryBlock);
	return useradd;
}

void operator delete(void *p) {
	//std::cout << "My delete" << std::endl;
	MemoryBlock *actualadd = reinterpret_cast<MemoryBlock*>( reinterpret_cast<char*>(p) - sizeof(MemoryBlock));
	g_Alloc.Deallocate(actualadd);
}