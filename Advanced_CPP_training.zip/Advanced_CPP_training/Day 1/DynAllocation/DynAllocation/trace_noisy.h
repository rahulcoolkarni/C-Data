#pragma once
#include <iostream>
#define _DOTRACE
//#define MOVE_SEMANTICS
#include "tracer.h"
class Number
{
	int m_Num;
public:
	Number()
	{
		TRACETHIS
	}
	 Number(int id) :m_Num(id)
	{
		TRACETHIS
	}
	Number(const Number & obj)
	{
		TRACETHIS
		m_Num = obj.m_Num;
	}
#ifdef MOVE_SEMANTICS
	Number( Number && obj)
	{
		TRACETHIS
		m_Num = obj.m_Num;
		obj.m_Num = 0;
	}
	Number &  operator =(Number &&obj)
	{
		TRACETHIS
			m_Num = obj.m_Num;
		obj.m_Num = 0;
		return *this;
	}
#endif
	Number &  operator =(const Number &obj)
	{
		TRACETHIS
		m_Num = obj.m_Num;
		return *this;
	}
	
	
	~Number()
	{
		TRACETHIS
	}
	int GetID()const {
		return m_Num;
	}
	Number & operator ++() {
		TRACETHIS
		++m_Num;
		return *this;
	}
	Number operator ++(int) {
		TRACETHIS
		Number temp(*this);
		++m_Num;
		return temp;
	}
	Number & operator +=(const Number &obj) {
		TRACETHIS
		m_Num += obj.m_Num;
		return *this;
	}
	Number operator +(const Number &obj) {
		TRACETHIS
		Number temp(*this);
		temp += obj;
		return temp;
	}
	friend bool operator < (const Number &lv, const Number &rv)
	{
		return lv.m_Num < rv.m_Num;
	}
	friend bool operator > (const Number &lv, const Number &rv)
	{
		return lv.m_Num > rv.m_Num;
	}
	friend bool operator == (const Number &lv, const Number &rv)
	{
		return lv.m_Num == rv.m_Num;
	}
	
};
inline std::ostream &operator<(std::ostream &out, const Number &obj) {
	out << obj.GetID();
	return out;
}