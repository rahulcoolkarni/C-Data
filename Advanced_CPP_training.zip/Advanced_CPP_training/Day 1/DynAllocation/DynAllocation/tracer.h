
/*****************************************************************
Author 	: Umar Majid Lone
Date 	: 5/8/2009
Note	: Will work only on Visual Studio 2003 onwards. 
		  To use on g++, substitute __FUNCSIG__ with __func__
*****************************************************************/

#ifndef _TRACE_H
#define _TRACE_H
#include <iostream>
	#ifdef _DOTRACE
	#define TRACETHIS std::cout << \
		__FUNCSIG__ <<std::endl; 
	#else
	#define TRACETHIS
	#endif
#endif