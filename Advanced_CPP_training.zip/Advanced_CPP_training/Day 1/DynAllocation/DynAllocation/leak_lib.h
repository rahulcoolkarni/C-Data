#pragma once
#include <list>
#include <ostream>
#include <iostream>

struct MemoryBlock {
	const int lineNumber;
	const char *pFunctionName;
	const char *pFileName;
	bool isFree = false;
	MemoryBlock(int ln, const char *fn, const char *file):
	lineNumber(ln),
	pFunctionName(fn),
		pFileName(file)
	{
		
	}
};
void * operator new(size_t size, int lineno, 
	const char *function, const char *file);
void operator delete(void *p);

#ifndef NDEBUG
#define DEBUG_NEW new(__LINE__, __FUNCSIG__, __FILE__)
#endif
class Allocator {
	std::list<MemoryBlock*> blocks;
public:
	void Allocate(MemoryBlock *p) {
		blocks.push_back(p);
	}
	void Deallocate(MemoryBlock *p) {
		/*for (std::list<MemoryBlock*>::iterator it = blocks.begin();
		it != blocks.end(); ++it) {
			
		}*/
		for(MemoryBlock *pBlock : blocks) {
			if(pBlock == p) {
				pBlock->isFree = true;
			}
		}
	}
	~Allocator() {
		int count = 0; 

		
		for (MemoryBlock *pBlock : blocks) {
			if (!pBlock->isFree) {
				std::cout << "****MEMORY LEAK****" << std::endl;
				std::cout << "Line : " << pBlock->lineNumber << std::endl;
				std::cout << "Function : " << pBlock->pFunctionName << std::endl;
				std::cout << "File : " << pBlock->pFileName << std::endl;
				++count;
			}
		}
		if (count >0) {
			std::cout << "Total allocations leaked : " << count << std::endl;
		}
	}
};

