#include "SString.h"
#include <iostream>
#include <cstring>
#include <stdexcept>
//#include <windows.h>
#include <limits>
void Display(const SString &p) {
	char ch = p[0];
	//p[0] = 'a';
	//MessageBoxA(nullptr, p.GetString(), "Title", MB_OK);
}
template<typename T, int size>
void Print(T (&ref)[size]) {

}

int main() {
//int WINAPI WinMain(HINSTANCE, HINSTANCE,  char *, int){
	int arr[50];
	int i = 10;
	int j = 5;
	j = i;
	int &ref = i;
	int (&p)[50] = arr;
	void(*pDisplay)(const SString &) = Display;
	Print(arr);
	std::cout << typeid(arr).name() << std::endl;
	SString s("Hello world");
	SString *ps = nullptr; 
	Display("Hello");

	Display(s);
	char ch = s[0];
	s[0] = 'a';

	try {
		int *p2 = new(std::nothrow) int[std::numeric_limits<int>::max()];
		if(p2 == nullptr) {
			std::cout << "Allocation failed" << std::endl;
		}
	}catch(std::exception &ex) {
		std::cout << "Exception caught : " << ex.what() << std::endl;
	}
	char buff[4];
	char *pBuff = (char*)malloc(8);
	int *p3 = new (buff)int[3];
	delete[] p3;
	return 0;
}