#include "SString.h"
#include <cstring>


SString::SString()
{
	m_p_str = nullptr;
	m_Length = 0;
}

SString::SString(const char* pstr) {
	m_Length = strlen(pstr);
	m_p_str = new char[m_Length + 1];
	strcpy(m_p_str, pstr);
}

SString::SString(const SString& obj) {
	m_Length = obj.m_Length;
	m_p_str = new char[m_Length + 1];
	strcpy(m_p_str, obj.m_p_str);
}

SString& SString::operator=(const SString& obj) {
	if (this != &obj) {
		SetString(obj.m_p_str);
	}
	return *this;
}

SString::~SString()
{
	delete []m_p_str;
}

int SString::GetLength()const {
	return m_Length;
}

const char* SString::GetString()const {
	return m_p_str;
}

void SString::SetString(const char* pstr) {
	delete []m_p_str;
	m_Length = strlen(pstr);
	m_p_str = new char[m_Length + 1];
	strcpy(m_p_str, pstr);
}